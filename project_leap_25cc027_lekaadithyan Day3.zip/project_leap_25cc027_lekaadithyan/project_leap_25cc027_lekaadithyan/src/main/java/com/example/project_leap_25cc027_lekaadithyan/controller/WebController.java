package com.example.project_leap_25cc027_lekaadithyan.controller;

import com.example.project_leap_25cc027_lekaadithyan.model.Student;
import com.example.project_leap_25cc027_lekaadithyan.services.WebService;
import com.example.project_leap_25cc027_lekaadithyan.services.impl.WebServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class WebController {
    @Autowired
    WebService webService;
    @PostMapping
    public Student addStudent(@RequestBody Student student)
    {
        return webService.saveStudent(student);
    }
    @GetMapping("/Details")
    List<Student> studentDetails(){
        return webService.readStudents();
    }
}

