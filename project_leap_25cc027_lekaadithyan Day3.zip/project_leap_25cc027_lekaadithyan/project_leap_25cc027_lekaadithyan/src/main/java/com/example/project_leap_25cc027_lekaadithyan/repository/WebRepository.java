package com.example.project_leap_25cc027_lekaadithyan.repository;

import com.example.project_leap_25cc027_lekaadithyan.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WebRepository extends JpaRepository<Student,Long> {
}
