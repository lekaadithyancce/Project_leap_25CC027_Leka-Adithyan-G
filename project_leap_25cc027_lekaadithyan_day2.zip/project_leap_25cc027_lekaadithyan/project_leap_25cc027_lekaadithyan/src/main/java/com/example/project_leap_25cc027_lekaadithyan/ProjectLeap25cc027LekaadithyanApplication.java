package com.example.project_leap_25cc027_lekaadithyan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc027LekaadithyanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc027LekaadithyanApplication.class, args);
	}
}
