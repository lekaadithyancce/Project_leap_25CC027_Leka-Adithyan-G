package com.example.project_leap_25cc027_lekaadithyan.controller;

import com.example.project_leap_25cc027_lekaadithyan.services.WebService;
import com.example.project_leap_25cc027_lekaadithyan.services.impl.WebServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @Autowired
    WebService webService;
    @PostMapping("/data")
    String writeData(String data)
    {
    return webService.writeData(data);
    }
    @GetMapping("/write")
    String getData()
    {

        return webService.readData();
    }
}

