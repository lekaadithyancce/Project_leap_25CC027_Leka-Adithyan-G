package com.example.project_leap_25cc027_lekaadithyan.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface WebRepository {
    String writeData(String data);
    String readData();
}
