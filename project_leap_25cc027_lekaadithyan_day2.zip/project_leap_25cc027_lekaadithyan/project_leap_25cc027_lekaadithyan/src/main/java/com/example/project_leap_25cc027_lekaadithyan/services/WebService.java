package com.example.project_leap_25cc027_lekaadithyan.services;

public interface WebService {
    public String writeData(String data);
    public String readData();
}

