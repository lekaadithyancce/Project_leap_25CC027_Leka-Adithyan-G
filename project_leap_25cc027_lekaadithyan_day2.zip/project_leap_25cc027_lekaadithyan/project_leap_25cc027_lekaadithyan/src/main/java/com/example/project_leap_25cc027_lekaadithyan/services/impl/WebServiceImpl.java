package com.example.project_leap_25cc027_lekaadithyan.services.impl;

import com.example.project_leap_25cc027_lekaadithyan.repository.WebRepository;
import com.example.project_leap_25cc027_lekaadithyan.repository.impl.WebRepositoryImpl;
import com.example.project_leap_25cc027_lekaadithyan.services.WebService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class WebServiceImpl implements WebService {
    @Autowired
    WebRepository webRepository;
    @Override
    public String writeData(String text)
    {
            return webRepository.writeData(text);

    }
    public String readData()
    {
        return webRepository.readData();
    }
}
