package com.example.project_leap_25cc027_lekaadithyan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25cc027LekaadithyanApplicationTests {

	@Test
	void contextLoads() {
	}

}
