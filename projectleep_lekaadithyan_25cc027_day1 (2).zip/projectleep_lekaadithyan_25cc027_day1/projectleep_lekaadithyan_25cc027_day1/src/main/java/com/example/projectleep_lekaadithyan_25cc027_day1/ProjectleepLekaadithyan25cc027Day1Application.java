package com.example.projectleep_lekaadithyan_25cc027_day1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectleepLekaadithyan25cc027Day1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectleepLekaadithyan25cc027Day1Application.class, args);
	}

}
