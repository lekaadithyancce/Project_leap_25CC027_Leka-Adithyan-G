package com.example.projectleep_lekaadithyan_25cc027_day1.controller;

public class Main {
    public static void main(String[] args){
        WebController webcontroller=new WebController();
        System.out.println(webcontroller.Calculate(10,20,"+"));
    }
}

