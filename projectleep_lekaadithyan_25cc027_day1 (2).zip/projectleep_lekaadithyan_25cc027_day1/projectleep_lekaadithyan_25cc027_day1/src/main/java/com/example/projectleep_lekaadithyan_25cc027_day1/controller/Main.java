package com.example.projectleep_lekaadithyan_25cc027_day1.controller;

public class Main {
    static void main(){
        WebController webcontroller = new WebController();
        IO.print(webcontroller.calculate(10 , 20 , "+"));
    }
}

