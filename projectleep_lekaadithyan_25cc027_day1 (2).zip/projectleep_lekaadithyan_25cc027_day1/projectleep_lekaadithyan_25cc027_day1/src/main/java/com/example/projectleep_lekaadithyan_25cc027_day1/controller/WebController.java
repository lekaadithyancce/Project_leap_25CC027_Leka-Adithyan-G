package com.example.projectleep_lekaadithyan_25cc027_day1.controller;

import com.example.projectleep_lekaadithyan_25cc027_day1.model.Location;
import com.example.projectleep_lekaadithyan_25cc027_day1.model.Student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {

    @PostMapping("/calculate")
    int Calculate(int a,int b,String operation){

        if("+".equals(operation)){
            return a+b;
        }
        else if("-".equals(operation)){
            return a-b;
        }
        else if("*".equals(operation)){
            return a*b;
        }
        else if("/".equals(operation)){
            return a/b;
        }
        return 0;
    }


    @GetMapping("/student")
    public Student getStudentDetails(){
        Student student = new Student();
        student.setName("LekaAdithyan");
        student.setDeptartment("CCE");
        student.setRollNo("25CC027");
        return student;
    }
    @PostMapping("/location")
    public Location getLocationDetails() {
        Location location = new Location();
        location.setName("Pollachi");
        location.setNo("1");
        return location;
    }
}
