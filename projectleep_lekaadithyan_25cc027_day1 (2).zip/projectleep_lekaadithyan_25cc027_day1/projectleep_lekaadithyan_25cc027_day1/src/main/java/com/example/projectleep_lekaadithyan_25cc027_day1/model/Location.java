package com.example.projectleep_lekaadithyan_25cc027_day1.model;

public class Location {
    String name;
    String no;
    public void setName(String name) {
        this.name = name;
    }

    public void setNo(String rollno) {
        this.no = rollno;
    }
    public String getNo() {
        return no;
    }

    public String getName() {
        return name;
    }
}
