package com.example.projectleep_lekaadithyan_25cc027_day1.model;

public class Student {

    private String name;
    private String rollNo;
    private String deptartment;

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeptartment() {
        return deptartment;
    }

    public void setDeptartment(String deptartment) {
        this.deptartment = deptartment;
    }
}

