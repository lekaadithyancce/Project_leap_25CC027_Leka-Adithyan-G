package com.example.projectleep_lekaadithyan_25cc027_day1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectleepLekaadithyan25cc027Day1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
